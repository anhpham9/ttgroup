import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  {
    path: '/',
    name: 'Home',
    component: () => import('@/views/Home.vue')
  },
  {
    path: '/countries',
    name: 'Countries',
    component: () => import('@/views/Countries.vue')
  },
  {
    path: '/countries/:id',
    name: 'CountryDetail',
    component: () => import('@/views/CountryDetail.vue')
  },
  {
    path: '/universities',
    name: 'Universities',
    component: () => import('@/views/Universities.vue')
  },
  {
    path: '/universities/:id',
    name: 'UniversityDetail',
    component: () => import('@/views/UniversityDetail.vue')
  },
  {
    path: '/programs',
    name: 'Programs',
    component: () => import('@/views/Programs.vue')
  },
  {
    path: '/programs/:id',
    name: 'ProgramDetail',
    component: () => import('@/views/ProgramDetail.vue')
  },
  {
    path: '/contact',
    name: 'Contact',
    component: () => import('@/views/Contact.vue')
  },
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue')
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/Register.vue')
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: () => import('@/views/Dashboard.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/profile',
    name: 'Profile',
    component: () => import('@/views/Profile.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/applications',
    name: 'Applications',
    component: () => import('@/views/Applications.vue'),
    meta: { requiresAuth: true }
  },
  {
    path: '/:pathMatch(.*)*',
    name: 'NotFound',
    component: () => import('@/views/NotFound.vue')
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition
    } else {
      return { top: 0 }
    }
  }
})

// Navigation guard
router.beforeEach((to, from, next) => {
  const authStore = useAuthStore()
  
  if (to.meta.requiresAuth && !authStore.isAuthenticated) {
    next('/login')
  } else {
    next()
  }
})

export default router
