const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all programs with university and country info
router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT p.*, u.name as university_name, u.city, c.name as country_name, c.code as country_code 
       FROM programs p 
       JOIN universities u ON p.university_id = u.id 
       JOIN countries c ON u.country_id = c.id 
       ORDER BY p.name ASC`
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching programs:', error);
    res.status(500).json({ error: 'Failed to fetch programs' });
  }
});

// Get program by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT p.*, u.name as university_name, u.city, u.website, c.name as country_name, c.code as country_code 
       FROM programs p 
       JOIN universities u ON p.university_id = u.id 
       JOIN countries c ON u.country_id = c.id 
       WHERE p.id = $1`,
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Program not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching program:', error);
    res.status(500).json({ error: 'Failed to fetch program' });
  }
});

// Search programs
router.get('/search', async (req, res) => {
  try {
    const { q, level, field, country, university, min_fee, max_fee } = req.query;
    let query = `
      SELECT p.*, u.name as university_name, u.city, c.name as country_name, c.code as country_code 
      FROM programs p 
      JOIN universities u ON p.university_id = u.id 
      JOIN countries c ON u.country_id = c.id 
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (q) {
      paramCount++;
      query += ` AND (p.name ILIKE $${paramCount} OR p.field_of_study ILIKE $${paramCount})`;
      params.push(`%${q}%`);
    }

    if (level) {
      paramCount++;
      query += ` AND p.level = $${paramCount}`;
      params.push(level);
    }

    if (field) {
      paramCount++;
      query += ` AND p.field_of_study ILIKE $${paramCount}`;
      params.push(`%${field}%`);
    }

    if (country) {
      paramCount++;
      query += ` AND c.name ILIKE $${paramCount}`;
      params.push(`%${country}%`);
    }

    if (university) {
      paramCount++;
      query += ` AND u.name ILIKE $${paramCount}`;
      params.push(`%${university}%`);
    }

    if (min_fee) {
      paramCount++;
      query += ` AND p.tuition_fee >= $${paramCount}`;
      params.push(parseFloat(min_fee));
    }

    if (max_fee) {
      paramCount++;
      query += ` AND p.tuition_fee <= $${paramCount}`;
      params.push(parseFloat(max_fee));
    }

    query += ' ORDER BY p.name ASC';

    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error searching programs:', error);
    res.status(500).json({ error: 'Failed to search programs' });
  }
});

// Get programs by field of study
router.get('/field/:field', async (req, res) => {
  try {
    const { field } = req.params;
    const { rows } = await pool.query(
      `SELECT p.*, u.name as university_name, u.city, c.name as country_name, c.code as country_code 
       FROM programs p 
       JOIN universities u ON p.university_id = u.id 
       JOIN countries c ON u.country_id = c.id 
       WHERE p.field_of_study ILIKE $1 
       ORDER BY p.name ASC`,
      [`%${field}%`]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching programs by field:', error);
    res.status(500).json({ error: 'Failed to fetch programs' });
  }
});

// Get programs by level
router.get('/level/:level', async (req, res) => {
  try {
    const { level } = req.params;
    const { rows } = await pool.query(
      `SELECT p.*, u.name as university_name, u.city, c.name as country_name, c.code as country_code 
       FROM programs p 
       JOIN universities u ON p.university_id = u.id 
       JOIN countries c ON u.country_id = c.id 
       WHERE p.level = $1 
       ORDER BY p.name ASC`,
      [level]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching programs by level:', error);
    res.status(500).json({ error: 'Failed to fetch programs' });
  }
});

// Create new program (admin only)
router.post('/', async (req, res) => {
  try {
    const { 
      name, 
      university_id, 
      level, 
      field_of_study, 
      duration_months, 
      tuition_fee, 
      description, 
      requirements, 
      application_deadline, 
      start_date, 
      language_requirements 
    } = req.body;
    
    if (!name || !university_id || !level || !field_of_study) {
      return res.status(400).json({ error: 'Name, university_id, level, and field_of_study are required' });
    }
    
    const { rows } = await pool.query(
      `INSERT INTO programs 
       (name, university_id, level, field_of_study, duration_months, tuition_fee, description, requirements, application_deadline, start_date, language_requirements) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11) 
       RETURNING *`,
      [name, university_id, level, field_of_study, duration_months, tuition_fee, description, requirements, application_deadline, start_date, language_requirements]
    );
    
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('Error creating program:', error);
    res.status(500).json({ error: 'Failed to create program' });
  }
});

// Update program (admin only)
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { 
      name, 
      university_id, 
      level, 
      field_of_study, 
      duration_months, 
      tuition_fee, 
      description, 
      requirements, 
      application_deadline, 
      start_date, 
      language_requirements 
    } = req.body;
    
    const { rows } = await pool.query(
      `UPDATE programs 
       SET name = $1, university_id = $2, level = $3, field_of_study = $4, duration_months = $5, 
           tuition_fee = $6, description = $7, requirements = $8, application_deadline = $9, 
           start_date = $10, language_requirements = $11, updated_at = CURRENT_TIMESTAMP 
       WHERE id = $12 
       RETURNING *`,
      [name, university_id, level, field_of_study, duration_months, tuition_fee, description, requirements, application_deadline, start_date, language_requirements, id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Program not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error updating program:', error);
    res.status(500).json({ error: 'Failed to update program' });
  }
});

// Delete program (admin only)
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      'DELETE FROM programs WHERE id = $1 RETURNING *',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Program not found' });
    }
    
    res.json({ message: 'Program deleted successfully' });
  } catch (error) {
    console.error('Error deleting program:', error);
    res.status(500).json({ error: 'Failed to delete program' });
  }
});

module.exports = router;
