const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all countries
router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      'SELECT * FROM countries ORDER BY name ASC'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching countries:', error);
    res.status(500).json({ error: 'Failed to fetch countries' });
  }
});

// Get country by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      'SELECT * FROM countries WHERE id = $1',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Country not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching country:', error);
    res.status(500).json({ error: 'Failed to fetch country' });
  }
});

// Get universities by country
router.get('/:id/universities', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT u.*, c.name as country_name 
       FROM universities u 
       JOIN countries c ON u.country_id = c.id 
       WHERE u.country_id = $1 
       ORDER BY u.ranking ASC`,
      [id]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching universities:', error);
    res.status(500).json({ error: 'Failed to fetch universities' });
  }
});

// Get programs by country
router.get('/:id/programs', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT p.*, u.name as university_name, c.name as country_name 
       FROM programs p 
       JOIN universities u ON p.university_id = u.id 
       JOIN countries c ON u.country_id = c.id 
       WHERE u.country_id = $1 
       ORDER BY p.name ASC`,
      [id]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching programs:', error);
    res.status(500).json({ error: 'Failed to fetch programs' });
  }
});

// Create new country (admin only)
router.post('/', async (req, res) => {
  try {
    const { name, code, flag_url, description } = req.body;
    
    if (!name || !code) {
      return res.status(400).json({ error: 'Name and code are required' });
    }
    
    const { rows } = await pool.query(
      'INSERT INTO countries (name, code, flag_url, description) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, code, flag_url, description]
    );
    
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('Error creating country:', error);
    if (error.code === '23505') { // Unique violation
      res.status(400).json({ error: 'Country with this name or code already exists' });
    } else {
      res.status(500).json({ error: 'Failed to create country' });
    }
  }
});

// Update country (admin only)
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { name, code, flag_url, description } = req.body;
    
    const { rows } = await pool.query(
      'UPDATE countries SET name = $1, code = $2, flag_url = $3, description = $4, updated_at = CURRENT_TIMESTAMP WHERE id = $5 RETURNING *',
      [name, code, flag_url, description, id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Country not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error updating country:', error);
    res.status(500).json({ error: 'Failed to update country' });
  }
});

// Delete country (admin only)
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      'DELETE FROM countries WHERE id = $1 RETURNING *',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Country not found' });
    }
    
    res.json({ message: 'Country deleted successfully' });
  } catch (error) {
    console.error('Error deleting country:', error);
    res.status(500).json({ error: 'Failed to delete country' });
  }
});

module.exports = router;
