const express = require('express');
const router = express.Router();
const pool = require('../config/database');

// Get all universities with country info
router.get('/', async (req, res) => {
  try {
    const { rows } = await pool.query(
      `SELECT u.*, c.name as country_name, c.code as country_code 
       FROM universities u 
       JOIN countries c ON u.country_id = c.id 
       ORDER BY u.ranking ASC`
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching universities:', error);
    res.status(500).json({ error: 'Failed to fetch universities' });
  }
});

// Get university by ID
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT u.*, c.name as country_name, c.code as country_code 
       FROM universities u 
       JOIN countries c ON u.country_id = c.id 
       WHERE u.id = $1`,
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'University not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching university:', error);
    res.status(500).json({ error: 'Failed to fetch university' });
  }
});

// Get programs by university
router.get('/:id/programs', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      `SELECT p.*, u.name as university_name 
       FROM programs p 
       JOIN universities u ON p.university_id = u.id 
       WHERE p.university_id = $1 
       ORDER BY p.name ASC`,
      [id]
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching programs:', error);
    res.status(500).json({ error: 'Failed to fetch programs' });
  }
});

// Search universities
router.get('/search', async (req, res) => {
  try {
    const { q, country, ranking } = req.query;
    let query = `
      SELECT u.*, c.name as country_name, c.code as country_code 
      FROM universities u 
      JOIN countries c ON u.country_id = c.id 
      WHERE 1=1
    `;
    const params = [];
    let paramCount = 0;

    if (q) {
      paramCount++;
      query += ` AND (u.name ILIKE $${paramCount} OR u.city ILIKE $${paramCount})`;
      params.push(`%${q}%`);
    }

    if (country) {
      paramCount++;
      query += ` AND c.name ILIKE $${paramCount}`;
      params.push(`%${country}%`);
    }

    if (ranking) {
      paramCount++;
      query += ` AND u.ranking <= $${paramCount}`;
      params.push(parseInt(ranking));
    }

    query += ' ORDER BY u.ranking ASC';

    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error searching universities:', error);
    res.status(500).json({ error: 'Failed to search universities' });
  }
});

// Create new university (admin only)
router.post('/', async (req, res) => {
  try {
    const { 
      name, 
      country_id, 
      city, 
      website, 
      logo_url, 
      description, 
      ranking, 
      tuition_fee_min, 
      tuition_fee_max, 
      acceptance_rate 
    } = req.body;
    
    if (!name || !country_id) {
      return res.status(400).json({ error: 'Name and country_id are required' });
    }
    
    const { rows } = await pool.query(
      `INSERT INTO universities 
       (name, country_id, city, website, logo_url, description, ranking, tuition_fee_min, tuition_fee_max, acceptance_rate) 
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10) 
       RETURNING *`,
      [name, country_id, city, website, logo_url, description, ranking, tuition_fee_min, tuition_fee_max, acceptance_rate]
    );
    
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('Error creating university:', error);
    res.status(500).json({ error: 'Failed to create university' });
  }
});

// Update university (admin only)
router.put('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { 
      name, 
      country_id, 
      city, 
      website, 
      logo_url, 
      description, 
      ranking, 
      tuition_fee_min, 
      tuition_fee_max, 
      acceptance_rate 
    } = req.body;
    
    const { rows } = await pool.query(
      `UPDATE universities 
       SET name = $1, country_id = $2, city = $3, website = $4, logo_url = $5, 
           description = $6, ranking = $7, tuition_fee_min = $8, tuition_fee_max = $9, 
           acceptance_rate = $10, updated_at = CURRENT_TIMESTAMP 
       WHERE id = $11 
       RETURNING *`,
      [name, country_id, city, website, logo_url, description, ranking, tuition_fee_min, tuition_fee_max, acceptance_rate, id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'University not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error updating university:', error);
    res.status(500).json({ error: 'Failed to update university' });
  }
});

// Delete university (admin only)
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      'DELETE FROM universities WHERE id = $1 RETURNING *',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'University not found' });
    }
    
    res.json({ message: 'University deleted successfully' });
  } catch (error) {
    console.error('Error deleting university:', error);
    res.status(500).json({ error: 'Failed to delete university' });
  }
});

module.exports = router;
