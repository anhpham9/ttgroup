const express = require('express');
const router = express.Router();
const pool = require('../config/database');
const nodemailer = require('nodemailer');

// Submit contact inquiry
router.post('/', async (req, res) => {
  try {
    const { name, email, phone, subject, message, country_of_interest, program_of_interest } = req.body;
    
    if (!name || !email || !subject || !message) {
      return res.status(400).json({ error: 'Name, email, subject, and message are required' });
    }
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      return res.status(400).json({ error: 'Invalid email format' });
    }
    
    // Save to database
    const { rows } = await pool.query(
      `INSERT INTO contact_inquiries 
       (name, email, phone, subject, message, country_of_interest, program_of_interest) 
       VALUES ($1, $2, $3, $4, $5, $6, $7) 
       RETURNING *`,
      [name, email, phone, subject, message, country_of_interest, program_of_interest]
    );
    
    // Send email notification (if email is configured)
    if (process.env.EMAIL_HOST && process.env.EMAIL_USER && process.env.EMAIL_PASS) {
      try {
        const transporter = nodemailer.createTransporter({
          host: process.env.EMAIL_HOST,
          port: process.env.EMAIL_PORT,
          secure: false,
          auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS,
          },
        });
        
        const mailOptions = {
          from: process.env.EMAIL_USER,
          to: process.env.EMAIL_USER, // Send to admin
          subject: `New Contact Inquiry: ${subject}`,
          html: `
            <h2>New Contact Inquiry</h2>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Phone:</strong> ${phone || 'Not provided'}</p>
            <p><strong>Subject:</strong> ${subject}</p>
            <p><strong>Message:</strong></p>
            <p>${message}</p>
            ${country_of_interest ? `<p><strong>Country of Interest:</strong> ${country_of_interest}</p>` : ''}
            ${program_of_interest ? `<p><strong>Program of Interest:</strong> ${program_of_interest}</p>` : ''}
            <p><strong>Submitted:</strong> ${new Date().toLocaleString()}</p>
          `
        };
        
        await transporter.sendMail(mailOptions);
      } catch (emailError) {
        console.error('Error sending email notification:', emailError);
        // Don't fail the request if email fails
      }
    }
    
    res.status(201).json({
      message: 'Contact inquiry submitted successfully',
      inquiry: rows[0]
    });
  } catch (error) {
    console.error('Error submitting contact inquiry:', error);
    res.status(500).json({ error: 'Failed to submit contact inquiry' });
  }
});

// Get all contact inquiries (admin only)
router.get('/', async (req, res) => {
  try {
    // In a real app, you'd add authentication middleware here
    const { rows } = await pool.query(
      'SELECT * FROM contact_inquiries ORDER BY created_at DESC'
    );
    res.json(rows);
  } catch (error) {
    console.error('Error fetching contact inquiries:', error);
    res.status(500).json({ error: 'Failed to fetch contact inquiries' });
  }
});

// Get contact inquiry by ID (admin only)
router.get('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      'SELECT * FROM contact_inquiries WHERE id = $1',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Contact inquiry not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching contact inquiry:', error);
    res.status(500).json({ error: 'Failed to fetch contact inquiry' });
  }
});

// Update contact inquiry status (admin only)
router.put('/:id/status', async (req, res) => {
  try {
    const { id } = req.params;
    const { status } = req.body;
    
    const validStatuses = ['new', 'in_progress', 'responded', 'closed'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const { rows } = await pool.query(
      `UPDATE contact_inquiries 
       SET status = $1, updated_at = CURRENT_TIMESTAMP 
       WHERE id = $2 
       RETURNING *`,
      [status, id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Contact inquiry not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error updating contact inquiry status:', error);
    res.status(500).json({ error: 'Failed to update contact inquiry status' });
  }
});

// Delete contact inquiry (admin only)
router.delete('/:id', async (req, res) => {
  try {
    const { id } = req.params;
    const { rows } = await pool.query(
      'DELETE FROM contact_inquiries WHERE id = $1 RETURNING *',
      [id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Contact inquiry not found' });
    }
    
    res.json({ message: 'Contact inquiry deleted successfully' });
  } catch (error) {
    console.error('Error deleting contact inquiry:', error);
    res.status(500).json({ error: 'Failed to delete contact inquiry' });
  }
});

// Get contact inquiry statistics (admin only)
router.get('/stats/overview', async (req, res) => {
  try {
    const stats = await pool.query(`
      SELECT 
        COUNT(*) as total_inquiries,
        COUNT(CASE WHEN status = 'new' THEN 1 END) as new_inquiries,
        COUNT(CASE WHEN status = 'in_progress' THEN 1 END) as in_progress,
        COUNT(CASE WHEN status = 'responded' THEN 1 END) as responded,
        COUNT(CASE WHEN status = 'closed' THEN 1 END) as closed,
        COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '7 days' THEN 1 END) as last_7_days,
        COUNT(CASE WHEN created_at >= CURRENT_DATE - INTERVAL '30 days' THEN 1 END) as last_30_days
      FROM contact_inquiries
    `);
    
    res.json(stats.rows[0]);
  } catch (error) {
    console.error('Error fetching contact inquiry stats:', error);
    res.status(500).json({ error: 'Failed to fetch contact inquiry statistics' });
  }
});

module.exports = router;
