# Study Abroad Website

A comprehensive study abroad advertising website built with Node.js backend, Vue 3 frontend, PostgreSQL database, and Tailwind CSS.

## Features

### For Students
- Browse study destinations and universities
- Search and filter programs by country, level, field of study
- User registration and authentication
- Application management dashboard
- Profile management
- Contact form for inquiries

### For Administrators
- Manage countries, universities, and programs
- View and manage student applications
- Handle contact inquiries
- User management
- Analytics and statistics

## Tech Stack

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **PostgreSQL** - Database
- **JWT** - Authentication
- **bcryptjs** - Password hashing
- **nodemailer** - Email functionality
- **multer** - File uploads
- **helmet** - Security middleware
- **cors** - Cross-origin resource sharing

### Frontend
- **Vue 3** - Progressive JavaScript framework
- **Vue Router** - Client-side routing
- **Pinia** - State management
- **Tailwind CSS** - Utility-first CSS framework
- **Axios** - HTTP client
- **Vue Toastification** - Toast notifications
- **Vite** - Build tool

## Prerequisites

Before running this project, make sure you have the following installed:

- **Node.js** (v16 or higher)
- **PostgreSQL** (v12 or higher)
- **npm** or **yarn**

## Installation

1. **Clone the repository**
   ```bash
   git clone <repository-url>
   cd study-abroad-website
   ```

2. **Install dependencies**
   ```bash
   npm run install-all
   ```

3. **Set up the database**
   - Create a PostgreSQL database named `study_abroad_db`
   - Update the database configuration in `backend/env.example` and rename it to `.env`
   ```bash
   cd backend
   cp env.example .env
   # Edit .env with your database credentials
   ```

4. **Initialize the database**
   ```bash
   npm run setup-db
   ```

5. **Start the development servers**
   ```bash
   npm run dev
   ```

This will start both the backend server (port 3000) and frontend development server (port 5173).

## Project Structure

```
study-abroad-website/
├── backend/                 # Node.js backend
│   ├── config/             # Database configuration
│   ├── routes/             # API routes
│   ├── scripts/            # Database setup scripts
│   ├── server.js           # Main server file
│   └── package.json        # Backend dependencies
├── frontend/               # Vue 3 frontend
│   ├── src/
│   │   ├── components/     # Vue components
│   │   ├── views/          # Page components
│   │   ├── stores/         # Pinia stores
│   │   ├── services/       # API services
│   │   ├── router/         # Vue Router configuration
│   │   └── style.css       # Global styles
│   ├── index.html          # HTML template
│   └── package.json        # Frontend dependencies
├── package.json            # Root package.json
└── README.md              # This file
```

## API Endpoints

### Authentication
- `POST /api/auth/register` - User registration
- `POST /api/auth/login` - User login
- `GET /api/auth/profile` - Get user profile
- `PUT /api/auth/profile` - Update user profile
- `PUT /api/auth/change-password` - Change password

### Countries
- `GET /api/countries` - Get all countries
- `GET /api/countries/:id` - Get country by ID
- `GET /api/countries/:id/universities` - Get universities by country
- `GET /api/countries/:id/programs` - Get programs by country

### Universities
- `GET /api/universities` - Get all universities
- `GET /api/universities/:id` - Get university by ID
- `GET /api/universities/:id/programs` - Get programs by university
- `GET /api/universities/search` - Search universities

### Programs
- `GET /api/programs` - Get all programs
- `GET /api/programs/:id` - Get program by ID
- `GET /api/programs/search` - Search programs
- `GET /api/programs/field/:field` - Get programs by field
- `GET /api/programs/level/:level` - Get programs by level

### Applications
- `GET /api/applications` - Get user applications
- `POST /api/applications` - Create application
- `PUT /api/applications/:id` - Update application
- `DELETE /api/applications/:id` - Delete application

### Contact
- `POST /api/contact` - Submit contact inquiry
- `GET /api/contact` - Get contact inquiries (admin)

## Environment Variables

Create a `.env` file in the backend directory with the following variables:

```env
# Server Configuration
PORT=3000
NODE_ENV=development

# Database Configuration
DB_HOST=localhost
DB_PORT=5432
DB_NAME=study_abroad_db
DB_USER=postgres
DB_PASSWORD=your_password

# JWT Configuration
JWT_SECRET=your_jwt_secret_key_here
JWT_EXPIRES_IN=7d

# Email Configuration (optional)
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USER=your_email@gmail.com
EMAIL_PASS=your_app_password

# File Upload Configuration
UPLOAD_PATH=./uploads
MAX_FILE_SIZE=5242880
```

## Available Scripts

### Root Level
- `npm run dev` - Start both backend and frontend in development mode
- `npm run server` - Start only the backend server
- `npm run client` - Start only the frontend development server
- `npm run build` - Build the frontend for production
- `npm run install-all` - Install dependencies for all packages
- `npm run setup-db` - Set up the database with sample data

### Backend
- `npm run dev` - Start backend with nodemon
- `npm start` - Start backend in production mode
- `npm run setup-db` - Initialize database tables and sample data

### Frontend
- `npm run dev` - Start Vite development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build

## Database Schema

The application includes the following main tables:

- **countries** - Study destinations
- **universities** - Educational institutions
- **programs** - Study programs
- **users** - User accounts
- **applications** - Student applications
- **contact_inquiries** - Contact form submissions
- **testimonials** - Student testimonials

## Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Support

For support, email support@studyabroad.com or create an issue in the repository.
