<template>
  <div class="min-h-screen">
    <!-- Hero Section -->
    <section class="bg-gradient-primary text-white">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
        <div class="text-center">
          <h1 class="text-4xl md:text-6xl font-bold mb-6">
            Your Gateway to
            <span class="text-yellow-300">Global Education</span>
          </h1>
          <p class="text-xl md:text-2xl mb-8 text-blue-100 max-w-3xl mx-auto">
            Discover study abroad opportunities in top universities worldwide. 
            Get expert guidance for your international education journey.
          </p>
          <div class="flex flex-col sm:flex-row gap-4 justify-center">
            <router-link to="/programs" class="btn-secondary text-lg px-8 py-4">
              Explore Programs
            </router-link>
            <router-link to="/contact" class="btn-outline text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-primary-600">
              Get Free Consultation
            </router-link>
          </div>
        </div>
      </div>
    </section>

    <!-- Stats Section -->
    <section class="bg-white py-16">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-8 text-center">
          <div>
            <div class="text-3xl font-bold text-primary-600 mb-2">500+</div>
            <div class="text-gray-600">Universities</div>
          </div>
          <div>
            <div class="text-3xl font-bold text-primary-600 mb-2">50+</div>
            <div class="text-gray-600">Countries</div>
          </div>
          <div>
            <div class="text-3xl font-bold text-primary-600 mb-2">1000+</div>
            <div class="text-gray-600">Programs</div>
          </div>
          <div>
            <div class="text-3xl font-bold text-primary-600 mb-2">95%</div>
            <div class="text-gray-600">Success Rate</div>
          </div>
        </div>
      </div>
    </section>

    <!-- Popular Countries -->
    <section class="py-16 bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
          <h2 class="text-3xl font-bold text-gray-900 mb-4">Popular Study Destinations</h2>
          <p class="text-lg text-gray-600">Explore top countries for international students</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <div v-for="country in popularCountries" :key="country.id" class="card-hover cursor-pointer" @click="goToCountry(country.id)">
            <div class="aspect-w-16 aspect-h-9 mb-4">
              <div class="w-full h-48 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center">
                <span class="text-white text-4xl font-bold">{{ country.code }}</span>
              </div>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">{{ country.name }}</h3>
            <p class="text-gray-600">{{ country.description }}</p>
          </div>
        </div>
        
        <div class="text-center mt-8">
          <router-link to="/countries" class="btn-primary">
            View All Countries
          </router-link>
        </div>
      </div>
    </section>

    <!-- Features Section -->
    <section class="py-16 bg-white">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
          <h2 class="text-3xl font-bold text-gray-900 mb-4">Why Choose Us?</h2>
          <p class="text-lg text-gray-600">Comprehensive support for your study abroad journey</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div class="text-center">
            <div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg class="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">Expert Guidance</h3>
            <p class="text-gray-600">Get personalized advice from experienced education consultants</p>
          </div>
          
          <div class="text-center">
            <div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg class="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">Application Support</h3>
            <p class="text-gray-600">Complete assistance with university applications and documentation</p>
          </div>
          
          <div class="text-center">
            <div class="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg class="w-8 h-8 text-primary-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
              </svg>
            </div>
            <h3 class="text-xl font-semibold text-gray-900 mb-2">Visa Assistance</h3>
            <p class="text-gray-600">Professional help with visa applications and requirements</p>
          </div>
        </div>
      </div>
    </section>

    <!-- Testimonials -->
    <section class="py-16 bg-gray-50">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
          <h2 class="text-3xl font-bold text-gray-900 mb-4">Student Success Stories</h2>
          <p class="text-lg text-gray-600">Hear from our successful students</p>
        </div>
        
        <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div v-for="testimonial in testimonials" :key="testimonial.id" class="card">
            <div class="flex items-center mb-4">
              <div class="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mr-4">
                <span class="text-primary-600 font-semibold">{{ testimonial.student_name.charAt(0) }}</span>
              </div>
              <div>
                <h4 class="font-semibold text-gray-900">{{ testimonial.student_name }}</h4>
                <p class="text-sm text-gray-600">{{ testimonial.university }}</p>
              </div>
            </div>
            <p class="text-gray-700 mb-4">{{ testimonial.testimonial }}</p>
            <div class="flex items-center">
              <div class="flex text-yellow-400">
                <svg v-for="i in testimonial.rating" :key="i" class="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                </svg>
              </div>
              <span class="ml-2 text-sm text-gray-600">{{ testimonial.country }}</span>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- CTA Section -->
    <section class="py-16 bg-primary-600 text-white">
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h2 class="text-3xl font-bold mb-4">Ready to Start Your Journey?</h2>
        <p class="text-xl mb-8 text-blue-100">Join thousands of students who have successfully studied abroad</p>
        <div class="flex flex-col sm:flex-row gap-4 justify-center">
          <router-link to="/register" class="btn-secondary text-lg px-8 py-4">
            Get Started Today
          </router-link>
          <router-link to="/contact" class="btn-outline text-lg px-8 py-4 border-white text-white hover:bg-white hover:text-primary-600">
            Contact Us
          </router-link>
        </div>
      </div>
    </section>
  </div>
</template>

<script setup>
import { ref, onMounted } from 'vue'
import { useRouter } from 'vue-router'
import api from '@/services/api'

const router = useRouter()
const popularCountries = ref([])
const testimonials = ref([])

const goToCountry = (id) => {
  router.push(`/countries/${id}`)
}

const fetchData = async () => {
  try {
    const [countriesResponse, testimonialsResponse] = await Promise.all([
      api.get('/countries'),
      api.get('/testimonials')
    ])
    
    popularCountries.value = countriesResponse.data.slice(0, 6)
    testimonials.value = testimonialsResponse.data.slice(0, 3)
  } catch (error) {
    console.error('Error fetching data:', error)
  }
}

onMounted(() => {
  fetchData()
})
</script>
