<template>
  <div class="min-h-screen bg-gray-50 flex flex-col justify-center py-12 sm:px-6 lg:px-8">
    <div class="max-w-md mx-auto text-center">
      <div class="mb-8">
        <div class="w-24 h-24 bg-gradient-primary rounded-full flex items-center justify-center mx-auto mb-6">
          <span class="text-white text-3xl font-bold">404</span>
        </div>
        <h1 class="text-6xl font-bold text-gray-900 mb-4">404</h1>
        <h2 class="text-2xl font-semibold text-gray-700 mb-4">Page Not Found</h2>
        <p class="text-gray-600 mb-8">
          Sorry, we couldn't find the page you're looking for. It might have been moved, 
          deleted, or you entered the wrong URL.
        </p>
      </div>
      
      <div class="space-y-4">
        <router-link to="/" class="btn-primary w-full">
          Go Back Home
        </router-link>
        <router-link to="/contact" class="btn-outline w-full">
          Contact Support
        </router-link>
      </div>
    </div>
  </div>
</template>

<script setup>
// No additional logic needed for this simple 404 page
</script>
