const pool = require('../config/database');

const createTables = async () => {
  try {
    // Create countries table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS countries (
        id SERIAL PRIMARY KEY,
        name VARCHAR(100) NOT NULL UNIQUE,
        code VARCHAR(3) NOT NULL UNIQUE,
        flag_url VARCHAR(255),
        description TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create universities table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS universities (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        country_id INTEGER REFERENCES countries(id) ON DELETE CASCADE,
        city VARCHAR(100),
        website VARCHAR(255),
        logo_url VARCHAR(255),
        description TEXT,
        ranking INTEGER,
        tuition_fee_min DECIMAL(10,2),
        tuition_fee_max DECIMAL(10,2),
        acceptance_rate DECIMAL(5,2),
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create programs table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS programs (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        university_id INTEGER REFERENCES universities(id) ON DELETE CASCADE,
        level VARCHAR(50) NOT NULL, -- Bachelor, Master, PhD, Diploma
        field_of_study VARCHAR(100) NOT NULL,
        duration_months INTEGER,
        tuition_fee DECIMAL(10,2),
        description TEXT,
        requirements TEXT,
        application_deadline DATE,
        start_date DATE,
        language_requirements TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create users table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        password_hash VARCHAR(255) NOT NULL,
        first_name VARCHAR(100) NOT NULL,
        last_name VARCHAR(100) NOT NULL,
        phone VARCHAR(20),
        date_of_birth DATE,
        nationality VARCHAR(100),
        role VARCHAR(20) DEFAULT 'student', -- student, admin, counselor
        is_active BOOLEAN DEFAULT true,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create applications table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS applications (
        id SERIAL PRIMARY KEY,
        user_id INTEGER REFERENCES users(id) ON DELETE CASCADE,
        program_id INTEGER REFERENCES programs(id) ON DELETE CASCADE,
        status VARCHAR(50) DEFAULT 'pending', -- pending, submitted, under_review, accepted, rejected
        application_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        documents_submitted JSONB,
        notes TEXT,
        counselor_notes TEXT,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create contact_inquiries table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS contact_inquiries (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) NOT NULL,
        phone VARCHAR(20),
        subject VARCHAR(255) NOT NULL,
        message TEXT NOT NULL,
        country_of_interest VARCHAR(100),
        program_of_interest VARCHAR(255),
        status VARCHAR(50) DEFAULT 'new', -- new, in_progress, responded, closed
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Create testimonials table
    await pool.query(`
      CREATE TABLE IF NOT EXISTS testimonials (
        id SERIAL PRIMARY KEY,
        student_name VARCHAR(255) NOT NULL,
        country VARCHAR(100) NOT NULL,
        university VARCHAR(255) NOT NULL,
        program VARCHAR(255) NOT NULL,
        testimonial TEXT NOT NULL,
        rating INTEGER CHECK (rating >= 1 AND rating <= 5),
        photo_url VARCHAR(255),
        is_featured BOOLEAN DEFAULT false,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      );
    `);

    console.log('✅ All tables created successfully');

    // Insert sample data
    await insertSampleData();

  } catch (error) {
    console.error('❌ Error creating tables:', error);
    throw error;
  }
};

const insertSampleData = async () => {
  try {
    // Insert sample countries
    const countries = [
      { name: 'United States', code: 'USA', flag_url: '/flags/usa.png', description: 'Land of opportunities with world-class universities' },
      { name: 'United Kingdom', code: 'GBR', flag_url: '/flags/uk.png', description: 'Home to prestigious institutions with rich academic traditions' },
      { name: 'Canada', code: 'CAN', flag_url: '/flags/canada.png', description: 'High-quality education in a welcoming multicultural environment' },
      { name: 'Australia', code: 'AUS', flag_url: '/flags/australia.png', description: 'Excellent education system with beautiful landscapes' },
      { name: 'Germany', code: 'DEU', flag_url: '/flags/germany.png', description: 'Affordable education with strong engineering programs' }
    ];

    for (const country of countries) {
      await pool.query(
        'INSERT INTO countries (name, code, flag_url, description) VALUES ($1, $2, $3, $4) ON CONFLICT (code) DO NOTHING',
        [country.name, country.code, country.flag_url, country.description]
      );
    }

    // Insert sample universities
    const universities = [
      { name: 'Harvard University', country_id: 1, city: 'Cambridge', website: 'https://harvard.edu', ranking: 1 },
      { name: 'Stanford University', country_id: 1, city: 'Stanford', website: 'https://stanford.edu', ranking: 2 },
      { name: 'University of Oxford', country_id: 2, city: 'Oxford', website: 'https://ox.ac.uk', ranking: 3 },
      { name: 'University of Toronto', country_id: 3, city: 'Toronto', website: 'https://utoronto.ca', ranking: 18 },
      { name: 'University of Melbourne', country_id: 4, city: 'Melbourne', website: 'https://unimelb.edu.au', ranking: 33 }
    ];

    for (const uni of universities) {
      await pool.query(
        'INSERT INTO universities (name, country_id, city, website, ranking) VALUES ($1, $2, $3, $4, $5) ON CONFLICT DO NOTHING',
        [uni.name, uni.country_id, uni.city, uni.website, uni.ranking]
      );
    }

    // Insert sample programs
    const programs = [
      { name: 'Computer Science', university_id: 1, level: 'Bachelor', field_of_study: 'Computer Science', duration_months: 48, tuition_fee: 50000 },
      { name: 'Business Administration', university_id: 2, level: 'Master', field_of_study: 'Business', duration_months: 24, tuition_fee: 75000 },
      { name: 'Engineering', university_id: 3, level: 'Bachelor', field_of_study: 'Engineering', duration_months: 48, tuition_fee: 35000 },
      { name: 'Medicine', university_id: 4, level: 'Bachelor', field_of_study: 'Medicine', duration_months: 72, tuition_fee: 45000 },
      { name: 'Data Science', university_id: 5, level: 'Master', field_of_study: 'Data Science', duration_months: 24, tuition_fee: 40000 }
    ];

    for (const program of programs) {
      await pool.query(
        'INSERT INTO programs (name, university_id, level, field_of_study, duration_months, tuition_fee) VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT DO NOTHING',
        [program.name, program.university_id, program.level, program.field_of_study, program.duration_months, program.tuition_fee]
      );
    }

    // Insert sample testimonials
    const testimonials = [
      { student_name: 'Nguyen Van A', country: 'United States', university: 'Harvard University', program: 'Computer Science', testimonial: 'Amazing experience studying abroad! The opportunities are endless.', rating: 5 },
      { student_name: 'Tran Thi B', country: 'United Kingdom', university: 'University of Oxford', program: 'Engineering', testimonial: 'The academic environment is challenging but rewarding.', rating: 5 },
      { student_name: 'Le Van C', country: 'Canada', university: 'University of Toronto', program: 'Business Administration', testimonial: 'Great multicultural experience and excellent education quality.', rating: 4 }
    ];

    for (const testimonial of testimonials) {
      await pool.query(
        'INSERT INTO testimonials (student_name, country, university, program, testimonial, rating) VALUES ($1, $2, $3, $4, $5, $6) ON CONFLICT DO NOTHING',
        [testimonial.student_name, testimonial.country, testimonial.university, testimonial.program, testimonial.testimonial, testimonial.rating]
      );
    }

    console.log('✅ Sample data inserted successfully');

  } catch (error) {
    console.error('❌ Error inserting sample data:', error);
    throw error;
  }
};

const setupDatabase = async () => {
  try {
    await createTables();
    console.log('🎉 Database setup completed successfully!');
    process.exit(0);
  } catch (error) {
    console.error('💥 Database setup failed:', error);
    process.exit(1);
  }
};

setupDatabase();
