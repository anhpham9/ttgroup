const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const pool = require('../config/database');

// Middleware to verify JWT token
const authenticateToken = (req, res, next) => {
  const token = req.headers.authorization?.split(' ')[1];
  if (!token) {
    return res.status(401).json({ error: 'No token provided' });
  }
  
  jwt.verify(token, process.env.JWT_SECRET, (err, decoded) => {
    if (err) {
      return res.status(401).json({ error: 'Invalid token' });
    }
    req.user = decoded;
    next();
  });
};

// Get all applications (for admin/counselor)
router.get('/', authenticateToken, async (req, res) => {
  try {
    let query;
    let params = [];
    
    if (req.user.role === 'admin' || req.user.role === 'counselor') {
      query = `
        SELECT a.*, u.first_name, u.last_name, u.email, p.name as program_name, 
               u.name as university_name, c.name as country_name
        FROM applications a
        JOIN users u ON a.user_id = u.id
        JOIN programs p ON a.program_id = p.id
        JOIN universities u ON p.university_id = u.id
        JOIN countries c ON u.country_id = c.id
        ORDER BY a.application_date DESC
      `;
    } else {
      // Students can only see their own applications
      query = `
        SELECT a.*, p.name as program_name, u.name as university_name, c.name as country_name
        FROM applications a
        JOIN programs p ON a.program_id = p.id
        JOIN universities u ON p.university_id = u.id
        JOIN countries c ON u.country_id = c.id
        WHERE a.user_id = $1
        ORDER BY a.application_date DESC
      `;
      params = [req.user.userId];
    }
    
    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (error) {
    console.error('Error fetching applications:', error);
    res.status(500).json({ error: 'Failed to fetch applications' });
  }
});

// Get application by ID
router.get('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    let query;
    let params = [id];
    
    if (req.user.role === 'admin' || req.user.role === 'counselor') {
      query = `
        SELECT a.*, u.first_name, u.last_name, u.email, p.name as program_name, 
               u.name as university_name, c.name as country_name
        FROM applications a
        JOIN users u ON a.user_id = u.id
        JOIN programs p ON a.program_id = p.id
        JOIN universities u ON p.university_id = u.id
        JOIN countries c ON u.country_id = c.id
        WHERE a.id = $1
      `;
    } else {
      query = `
        SELECT a.*, p.name as program_name, u.name as university_name, c.name as country_name
        FROM applications a
        JOIN programs p ON a.program_id = p.id
        JOIN universities u ON p.university_id = u.id
        JOIN countries c ON u.country_id = c.id
        WHERE a.id = $1 AND a.user_id = $2
      `;
      params = [id, req.user.userId];
    }
    
    const { rows } = await pool.query(query, params);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Application not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error fetching application:', error);
    res.status(500).json({ error: 'Failed to fetch application' });
  }
});

// Create new application
router.post('/', authenticateToken, async (req, res) => {
  try {
    const { program_id, notes } = req.body;
    
    if (!program_id) {
      return res.status(400).json({ error: 'Program ID is required' });
    }
    
    // Check if program exists
    const programCheck = await pool.query('SELECT * FROM programs WHERE id = $1', [program_id]);
    if (programCheck.rows.length === 0) {
      return res.status(404).json({ error: 'Program not found' });
    }
    
    // Check if user already applied to this program
    const existingApplication = await pool.query(
      'SELECT * FROM applications WHERE user_id = $1 AND program_id = $2',
      [req.user.userId, program_id]
    );
    
    if (existingApplication.rows.length > 0) {
      return res.status(400).json({ error: 'You have already applied to this program' });
    }
    
    const { rows } = await pool.query(
      `INSERT INTO applications (user_id, program_id, notes) 
       VALUES ($1, $2, $3) 
       RETURNING *`,
      [req.user.userId, program_id, notes]
    );
    
    res.status(201).json(rows[0]);
  } catch (error) {
    console.error('Error creating application:', error);
    res.status(500).json({ error: 'Failed to create application' });
  }
});

// Update application status (admin/counselor only)
router.put('/:id/status', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin' && req.user.role !== 'counselor') {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    const { id } = req.params;
    const { status, counselor_notes } = req.body;
    
    const validStatuses = ['pending', 'submitted', 'under_review', 'accepted', 'rejected'];
    if (!validStatuses.includes(status)) {
      return res.status(400).json({ error: 'Invalid status' });
    }
    
    const { rows } = await pool.query(
      `UPDATE applications 
       SET status = $1, counselor_notes = $2, updated_at = CURRENT_TIMESTAMP 
       WHERE id = $3 
       RETURNING *`,
      [status, counselor_notes, id]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Application not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error updating application status:', error);
    res.status(500).json({ error: 'Failed to update application status' });
  }
});

// Update application (user can only update notes)
router.put('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    const { notes } = req.body;
    
    let query;
    let params;
    
    if (req.user.role === 'admin' || req.user.role === 'counselor') {
      query = `
        UPDATE applications 
        SET notes = $1, updated_at = CURRENT_TIMESTAMP 
        WHERE id = $2 
        RETURNING *
      `;
      params = [notes, id];
    } else {
      query = `
        UPDATE applications 
        SET notes = $1, updated_at = CURRENT_TIMESTAMP 
        WHERE id = $2 AND user_id = $3 
        RETURNING *
      `;
      params = [notes, id, req.user.userId];
    }
    
    const { rows } = await pool.query(query, params);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Application not found' });
    }
    
    res.json(rows[0]);
  } catch (error) {
    console.error('Error updating application:', error);
    res.status(500).json({ error: 'Failed to update application' });
  }
});

// Delete application
router.delete('/:id', authenticateToken, async (req, res) => {
  try {
    const { id } = req.params;
    
    let query;
    let params;
    
    if (req.user.role === 'admin' || req.user.role === 'counselor') {
      query = 'DELETE FROM applications WHERE id = $1 RETURNING *';
      params = [id];
    } else {
      query = 'DELETE FROM applications WHERE id = $1 AND user_id = $2 RETURNING *';
      params = [id, req.user.userId];
    }
    
    const { rows } = await pool.query(query, params);
    
    if (rows.length === 0) {
      return res.status(404).json({ error: 'Application not found' });
    }
    
    res.json({ message: 'Application deleted successfully' });
  } catch (error) {
    console.error('Error deleting application:', error);
    res.status(500).json({ error: 'Failed to delete application' });
  }
});

// Get application statistics (admin only)
router.get('/stats/overview', authenticateToken, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Access denied' });
    }
    
    const stats = await pool.query(`
      SELECT 
        COUNT(*) as total_applications,
        COUNT(CASE WHEN status = 'pending' THEN 1 END) as pending,
        COUNT(CASE WHEN status = 'submitted' THEN 1 END) as submitted,
        COUNT(CASE WHEN status = 'under_review' THEN 1 END) as under_review,
        COUNT(CASE WHEN status = 'accepted' THEN 1 END) as accepted,
        COUNT(CASE WHEN status = 'rejected' THEN 1 END) as rejected
      FROM applications
    `);
    
    res.json(stats.rows[0]);
  } catch (error) {
    console.error('Error fetching application stats:', error);
    res.status(500).json({ error: 'Failed to fetch application statistics' });
  }
});

module.exports = router;
